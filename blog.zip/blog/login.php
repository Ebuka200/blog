<?php 
    
    include 'admin/includes/config.php';

    $conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);

    if(isset($_POST['submit'])){
        $err_flag = false;
        if (empty($_POST['username'])){
            $err_flag = true;
            $err_msg = 'Empty field not allowed';
        }
        else{
            $username = $_POST['username'];
        }

        if (empty($_POST['password'])){
            $err_flag = true;
            $err_msg = 'Empty field not allowed';
        }
    
    else{
        $password = $_POST['password'];
        $password = md5($password);
    }    


    if(isset($err_flag) && $err_flag === false){

        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM admin where username = '$username' and password = '$password'";

        $query = mysqli_query($conn, $sql);
        if(mysqli_num_rows($query) > 0){
          while ($row = mysqli_fetch_assoc($query)){
              session_start();
              
              $_SESSION['auth'] = true;
              $_SESSION['username'] = $row['username'];
          }
          if ($_SESSION['auth'] === true){
              header("Location: admin/index.php");
              exit();
          }
      }else{
          echo "<script>
                   alert('Incorrect Details');
               </script>"; 
           header("Location: login.php");
           $error = true;
      }


    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>login</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans+Thai+Looped&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <section class="login-clean">
        <form method="post" style="width: 458px;height: 467px;" role="form" action="login.php" enctype="multipart/form-data">
            <h2 class="visually-hidden">Login Form</h2>
            <div class="illustration"><i class="icon ion-ios-navigate text-primary" style="border-color: var(--bs-indigo);"></i></div>
            <div class="mb-3"><input class="form-control" type="text" name="username" placeholder="Username" style="font-family: 'IBM Plex Sans Thai Looped', sans-serif;"></div>
            <div class="mb-3"><input class="form-control" type="password" name="password" placeholder="Password" style="font-family: 'IBM Plex Sans Thai Looped', sans-serif;"></div>
            <input class="btn btn-info d-block btn-user w-100" type="submit" name="submit" value="Login">

            <a class="forgot mt-4" href="index.php">Home</a>

        </form>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>