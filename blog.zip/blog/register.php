<?php
    include 'admin/includes/config.php';

    $conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);

    // echo "YEsssss";
    if(isset($_POST['submit'])){


        //Getting values from forms
        $firstname = $_POST['firstname'];   
        $lastname = $_POST['lastname'];   
        $email = $_POST['email'];
        $username = $_POST['username']; 
        $password = $_POST['password'];

        $sql = "INSERT INTO admin(firstname, lastname, email, username, password) values('$firstname', '$lastname', '$email','$username','$password')";

        // $sql = "INSERT INTO user(firstname, lastname, passport, email_address, company, position, address, age, cell_number , gender, password) values('asd','asd', 'asd','asd@c','asd','asd','asd','1','1','asd','asd')";

        $query = mysqli_query($conn, $sql);
        // if(in_array($file_ext,$extensions)=== false){
        //     $errors[]="extension not allowed, please choose a JPEG or PNG file.";
        //  }


        $error2 = false;
        var_dump($query);
        if($query){
            $error2 = true;

            echo "<script>
                    alert('Profile Created');
                    location.href ='login.php';
                    
                </script>"; 
        }else {
            
            echo "<script>alert('Profile not created!');
            location.href ='register.php';
                        </script>";
        }
    }


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>register</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Registration-Form-with-Photo.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <section class="register-photo">
        <div class="form-container">
            <div class="image-holder"></div>
            <form method="post" role="form" action="register.php" enctype="multipart/form-data">
                <h2 class="text-center"><strong>Create</strong> an account.</h2>
                <div class="mb-3"><input class="form-control" type="text" name="firstname" placeholder="Firstname"></div>
                <div class="mb-3"><input class="form-control" type="tect" name="lastname" placeholder="Lastname"></div>
                <div class="mb-3"><input class="form-control" type="email" name="email" placeholder="Email"></div>
                <div class="mb-3"><input class="form-control" type="text" name="username" placeholder="Username"></div>
                <div class="mb-3"><input class="form-control" type="password" name="password" placeholder="Password (repeat)"></div>
                <div class="mb-3">
                    <div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox">I agree to the license terms.</label></div>
                </div>
                <input class="btn btn-primary d-block btn-user w-100" type="submit" name="submit" value="Register">
            </form>
        </div>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>