<?php 

session_start();
include 'includes/config.php';
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);

function truncate($text, $chars = 25) {
    if (strlen($text) <= $chars) {
        return $text;
    }
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;
}



$flag = true;

if (!(isset($_SESSION['email']))) {
    
    $flag = false;

}else{
      $email = $_SESSION["email"];
      
      $session_sql = "SELECT * FROM users WHERE email = '$email'";
      $session_query = mysqli_query($conn, $session_sql);
      if($session_query){
          $session_row = mysqli_num_rows($session_query);
      }
}

if (!(isset($_SESSION['username']))) {
    
    $flag = false;

}else{
      $username = $_SESSION["username"];
      
      $session_sql = "SELECT * FROM admin WHERE username = '$username'";
      $session_query = mysqli_query($conn, $session_sql);
      if($session_query){
          $session_row = mysqli_num_rows($session_query);
      }
}



if (!(isset($_SESSION['username']))) {
    
    $flag2 = false;
    echo "<script>
    
    location.href ='login.php';
  </script>"; 

}else{
      $username = $_SESSION["username"];
      
      $session_sql2 = "SELECT * FROM post WHERE author = '$username'";
      $session_query2 = mysqli_query($conn, $session_sql2);
      if($session_query2){
          $session_row2 = mysqli_num_rows($session_query2);
      }
}

if (!(isset($_SESSION['email']))) {
    
    $flag2 = false;


}else{
      $username = $_SESSION["email"];
      
      $session_sql2 = "SELECT * FROM post WHERE author = '$username'";
      $session_query2 = mysqli_query($conn, $session_sql2);
      if($session_query2){
          $session_row2 = mysqli_num_rows($session_query2);
      }
}

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dashboard - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php' ?>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
               <?php include "includes/navbar.php" ?>
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">Dashboard</h3><a class="btn btn-primary btn-sm d-none d-sm-inline-block" role="button" href="#"><i class="fas fa-download fa-sm text-white-50"></i>&nbsp;Generate Report</a>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-primary py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>Posts</span></div>
                                            <div class="text-dark fw-bold h5 mb-0"><span>40,000</span></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-calendar fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-success py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>Comments (Total)</span></div>
                                            <div class="text-dark fw-bold h5 mb-0"><span>215,000</span></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-dollar-sign fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-info py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-info fw-bold text-xs mb-1"><span>Tasks</span></div>
                                            <div class="row g-0 align-items-center">
                                                <div class="col-auto">
                                                    <div class="text-dark fw-bold h5 mb-0 me-3"><span>50%</span></div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm">
                                                        <div class="progress-bar bg-info" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;"><span class="visually-hidden">50%</span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <div class="card shadow border-start-warning py-2">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-warning fw-bold text-xs mb-1"><span>Pending Requests</span></div>
                                            <div class="text-dark fw-bold h5 mb-0"><span>18</span></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                    
                        <div class="row">
                        <div class="d-sm-flex justify-content-between align-items-center  mt-5">
                        <h3 class="text-dark mb-0">My posts</h3><a class="btn btn-primary btn-sm d-none d-sm-inline-block" role="button" href="#"><i class="fas fa-download fa-sm text-white-50"></i>&nbsp;Generate Report</a>
                    </div>
                    <?php 
                        if(isset($_SESSION['username'])){
                            while($session_row2 = mysqli_fetch_assoc($session_query2)){
                                $title = $session_row2['title'];
                                $category = $session_row2['category'];
                                $description = $session_row2['description'];
                                $thumbnail = $session_row2['thumbnail'];
                                $date = $session_row2['date'];
                                $postid = $session_row2['postid'];
                                
                           
                        ?>
                            <div class="col-md-4" style="margin-top: 30px;">
                                <div class="card" style=><img class="card-img-top w-100 d-block" src="../<?php echo $thumbnail  ?>" height="200px">
                                    <div class="card-body" style="height: 250px;padding-bottom: 30px;box-shadow: 0px 0px 6px var(--bs-gray-500);">
                                        <h4 class="card-title text-dark" style="padding-top: 20px;padding-left: 20px;font-weight: bold;"><?php echo truncate($title, 50)  ?></h4>
                                        <p class="card-text text-dark" style="padding-left: 20px;padding-right: 20px;font-size: 13px;padding-bottom: 0px;"><?php echo truncate($description, 60) ?></p>
                                        <!-- <small style="background: var(--bs-blue);color: var(--bs-white);padding: 5px;margin-left: 20px;margin-bottom: 30px;margin-top: -3px;"><?php echo $category ?></small> -->
                                        <div class="row">
                                            <div class="col-6">
                                                <small style="background: var(--bs-blue);color: var(--bs-white);padding: 5px;margin-left: 20px;margin-bottom: 20px;margin-top: 10px;"><?php echo $category ?></small>
                                            </div>
                                            <div class="col-6">
                                                <a href="delete.php?postid=<?php echo $postid ?>" type="button"  style="float: right; margin-right: 20px; font-size: 25px; color: red">
                                                    <span class="fa fa-trash"></span>
                                                </a>
                                                
                                                <a style="float: right; margin-right: 20px;  font-size: 25px" href="update.php?postid=<?php echo $postid?>">
                                                    <span class="fa fa-pencil"></span>
                                                </a>
                                               
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                        <?php }} ?>

                        <?php 
                        if(isset($_SESSION['email'])){
                            while($session_row2 = mysqli_fetch_assoc($session_query2)){
                                $title = $session_row2['title'];
                                $category = $session_row2['category'];
                                $description = $session_row2['description'];
                                $thumbnail = $session_row2['thumbnail'];
                                $date = $session_row2['date'];
                                $postid = $session_row2['postid'];
                                
                           
                        ?>
                        <div class="col-md-4" style="margin-top: 30px;">
                                <div class="card"><img class="card-img-top w-100 d-block" src="../<?php echo $thumbnail  ?>" height="200px">
                                    <div class="card-body" style="padding-bottom: 30px;box-shadow: 0px 0px 6px var(--bs-gray-500);">
                                        <h4 class="card-title text-dark" style="padding-top: 20px;padding-left: 20px;font-weight: bold;"><?php echo truncate($title, 50)  ?></h4>
                                        <p class="card-text text-dark" style="padding-left: 20px;padding-right: 20px;font-size: 13px;padding-bottom: 0px;"><?php echo truncate($description, 60) ?></p>
                                        <!-- <small style="background: var(--bs-blue);color: var(--bs-white);padding: 5px;margin-left: 20px;margin-bottom: 30px;margin-top: -3px;"><?php echo $category ?></small> -->
                                        <div class="row">
                                            <div class="col-6">
                                                <small style="background: var(--bs-blue);color: var(--bs-white);padding: 5px;margin-left: 20px;margin-bottom: 30px;margin-top: -3px;"><?php echo $category ?></small>
                                            </div>
                                            <div class="col-6">
                                                <a href="update.php?postid=<?php echo $postid?>">
                                                    <span class="fa fa-pencil"></span>
                                                </a>
                                                <a  href="delete.php?postid=<?php echo $postid?>">
                                                    <span class="fa fa-trash"></span>
                                                </a>
                                                
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php }} ?>
                            
                </div>
    </div>

                </div>
            </div>
            <?php 
                        if(isset($_SESSION['username'])){
                            while($session_row2 = mysqli_fetch_assoc($session_query2)){
                               
                                $postid = urlencode($session_row2['postid']);
                                
                           
                        ?>
                        
                <?php }} ?>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Brand 2022</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>