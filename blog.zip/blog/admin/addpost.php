<?php
    session_start();
    include 'includes/config.php';

    $conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);


    
if (!(isset($_SESSION['email']))) {
    
    $flag = false;

}else{
      $email = $_SESSION["email"];
      
      $session_sql = "SELECT * FROM users WHERE email = '$email'";
      $session_query = mysqli_query($conn, $session_sql);
      if($session_query){
          $session_row = mysqli_num_rows($session_query);
      }
}

if (!(isset($_SESSION['username']))) {
    
    $flag = false;

}else{
      $username = $_SESSION["username"];
      
      $session_sql = "SELECT * FROM admin WHERE username = '$username'";
      $session_query = mysqli_query($conn, $session_sql);
      if($session_query){
          $session_row = mysqli_num_rows($session_query);
      }
}






    // echo "YEsssss";
    if(isset($_POST['submit'])){


        //Getting values from forms
        $title = $_POST['title'];   
        $category = $_POST['category'];   
        $description = $_POST['description'];
        $author = $_POST['author'];
        


        $filename = $_FILES["thumbnail"]["name"];
        $tempname = $_FILES["thumbnail"]["tmp_name"];
        $file_type= $_FILES['thumbnail']['type'];
        $file_size= $_FILES['thumbnail']['size'];
        // $file_ext=strtolower(end(explode('.',$_FILES['avatar']['name'])));

        $extensions= array("jpeg","jpg","png");
        $folder = "thumbnail/".$filename;

        $postid = $_POST['postid'];

        $sql = "INSERT INTO post(title, author, category, description, thumbnail, postid) values('$title', '$author' , '$category', '$description','$folder', '$postid')";

        // $sql = "INSERT INTO user(firstname, lastname, passport, email_address, company, position, address, age, cell_number , gender, password) values('asd','asd', 'asd','asd@c','asd','asd','asd','1','1','asd','asd')";

        $query = mysqli_query($conn, $sql);
        // if(in_array($file_ext,$extensions)=== false){
        //     $errors[]="extension not allowed, please choose a JPEG or PNG file.";
        //  }

         if($file_size > 2097152){
            $errors[]='File size must be excately 2 MB';
         }
         
         if(empty($errors)==true){
            move_uploaded_file($tempname,"../thumbnail/".$filename);
            echo "Success";
         }else{
            print_r($errors);
         }


        $error2 = false;
        var_dump($query);
        if($query){
            $error2 = true;

            echo "<script>
                    alert('Successfully created! ');
                    location.href ='index.php';
                    
                </script>"; 
        }else {
            
            echo "<script>alert('Post not created');
            
                        </script>";
        }
    }


?>



<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dashboard - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php' ?>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <?php include "includes/navbar.php" ?>

                <div class="container-fluid">
                    <div class="card o-hidden border-0 shadow-lg my-5" style="height: auto;">
                        <div class="card-body p-0">
                            <!-- Nested Row within Card Body -->
                            <div class="row row justify-content-center align-items-center h-100">
                                <!-- <div class="col-lg-6 d-none d-lg-block bg-login-image"></div> -->
                                <div class="col-lg-6">
                                    <div class="p-5">
                                    <div class="text-center">
                                    
                                    <h1 class="h4 text-gray-900 mb-4 mt-5">Create Post</h1>
                                </div>
                                <form class="user" role="form" action="addpost.php" method="post" enctype="multipart/form-data">
                                    <div class="form-group mb-3" >
                                        <input type="text" style="border-radius: 5px" rows="5" class="form-control form-control-user" name="author" id="exampleInputEmail" aria-describedby="emailHelp" value="<?php echo $_SESSION['username'] ?>">
                                    </div>

                                    <div class="form-group mb-3" >
                                        <input type="text" style="border-radius: 5px" rows="5" class="form-control form-control-user" name="title" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Title...">
                                    </div>
                                
                                    <div class="form-group mb-3">
                                    
                                        <select class="form-control" name="category" id="exampleInputEmail" aria-describedby="emailHelp" style="height: 50px; font-size: 13px">
                                            <option  value="null">Category</option>
                                            <option value="Lifestyle">Lifestyle</option>
                                            <option value="Education">Education</option>
                                            <option value="Travel">Travel</option>
                                            <option value="Food">Food</option>
                                            <option value="Health">Health</option>
                                            <option value="News">News</option>
                                            <option value="Finance & Business">Finance & Business</option>
                                            <option value="Politics">Politics</option>
                                            <option value="Tech">Tech</option>
                                            <option value="Gist">Gist</option>
                                        </select>  
                                    
                                    </div>

                                    <div class="form-group mb-3">
                                    <textarea col="8" rows="8" style="border-radius: 5px" type="text" class="form-control form-control-user" name="description" id="exampleInputPassword" placeholder="Description" ></textarea>
                                    </div>

                                    <div class="form-group mb-3" >
                                        <label>Thumbnail:</label>
                                        <input type="file" style="border-radius: 5px" rows="5" class="form-control form-control-user" name="thumbnail" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Title...">
                                    </div>


                                    <div class="form-group d-none">
                                        <input type="text" rows="5" class="form-control form-control-user" name="postid" id="exampleInputEmail" aria-describedby="emailHelp" 
                                        
                                        value="<?php 
                                        
                                        $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    
                                        function generate_string($input, $strength = 16) {
                                            $input_length = strlen($input);
                                            $random_string = '';
                                            for($i = 0; $i < $strength; $i++) {
                                                $random_character = $input[mt_rand(0, $input_length - 1)];
                                                $random_string .= $random_character;
                                            }
                                        
                                            return $random_string;
                                        }
                                        
                                        // Output: iNCHNGzByPjhApvn7XBD
                                        echo generate_string($permitted_chars, 7);
                                    
                                        
                                        ?>">
                                    </div>

                                

                                    
                                
                                    <input href="" class="mb-5 btn btn-primary btn-user btn-block" style="border-radius: 5px" type="submit" name="submit" value="Submit"/>
                                    
                                
                                </form>
                                
                        </div>
                    </div>
                </div>
                        
                            
                </div>
             </div>
                    
        </div>
    </div>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Brand 2022</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>