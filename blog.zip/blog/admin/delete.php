<?php 
include 'includes/config.php';
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);

    if (isset($_GET['postid'])) {
        $postid = $_GET['postid'];
        $sql = "DELETE FROM post where postid = '$postid'";
        $query = mysqli_query($conn, $sql);

        echo $id;
        header ("Location: index.php");
    }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Warning</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            Are you sure you want to delete this post? <?php echo $postid ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                                            <a href="delete.php?postid=<?php echo $postid ?>"><button type="button" class="btn btn-danger" >Delete</button></a>

                                        </div>
                                    </div>
                                </div>

                            </div>
</body>
</html>