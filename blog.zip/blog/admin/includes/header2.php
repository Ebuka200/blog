<nav id="topNav" class="navbar navbar-expand-lg navbar-default fixed-top">
                            <div class="container-fluid p-5">
                                <h3 class="navbar-header">aminaami</h3>
                                    
                                <button class="navbar-toggler text-white" data-toggle="collapse" type="button"  data-target="#navbarNav">
                                    <p class="fa fa-align-right mt-3"></p>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarNav">
        
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="admin.php" class="nav-link">Home</a>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Add
                                            </a>
                                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="addmessage.php">Message</a>
                                            <a class="dropdown-item" href="addofficer.php">Officer</a>

                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="adddepartment.php">Department</a>
                                            </div>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="users.php" class="nav-link">Users</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="feedbackdetails.php" class="nav-link">Feedback</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="messages.php" class="nav-link">Messages</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="blacklist.php" class="nav-link">Blacklist</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="officers.php" class="nav-link">Officers</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="departments.php" class="nav-link">Departments</a>
                                        </li>
                                        
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="login.php" class="nav-link">Logout</a>
                                        </li>
                                    </ul>
                                </div>  
    
                            </div>
                        </nav>