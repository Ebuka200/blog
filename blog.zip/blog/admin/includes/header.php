<nav id="topNav" class="navbar navbar-expand-lg navbar-default fixed-top">
                            <div class="container-fluid p-5">
                                <h3 class="navbar-header">aminaami</h3>
                                    
                                <button class="navbar-toggler text-white" data-toggle="collapse" type="button"  data-target="#navbarNav">
                                    <p class="fa fa-align-right mt-3"></p>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarNav">
        
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="index.php" class="nav-link">Home</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="login.php" class="nav-link">Login</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="register.php" class="nav-link">Register</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="checkin.php" class="nav-link">Check In</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="notifications.php" class="nav-link">Notifications</a>
                                        </li>
                                        <li class="nav-item w-sm-100 text-center">
                                            <a href="checkindetails.php" class="nav-link">Details</a>
                                        </li>

                                    </ul>
                                </div>  
    
                            </div>
                        </nav>