<?php

include 'admin/includes/config.php';
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);

function truncate($text, $chars = 25) {
    if (strlen($text) <= $chars) {
        return $text;
    }
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alatsi&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Highlight-Phone.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
<nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container">
            <a class="navbar-brand" href="#" style="color: var(--bs-blue);font-size: 30px;">
                <img src="thumbnail/logo.jpeg" alt="" width="50"  height="50">
            </a>
            <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1">
                <span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link " href="index.php" style="font-family: Alatsi, sans-serif;">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php" style="font-family: Alatsi, sans-serif;">Admin</a></li>
                    <li class="nav-item dropdown"><a class="dropdown-toggle nav-link active" aria-expanded="false" data-bs-toggle="dropdown" href="#" style="font-family: Alatsi, sans-serif;">Categories </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="category.php?category=Lifestyles">Lifestyle</a>
                            <a class="dropdown-item" href="category.php?category=Education">Education</a>
                            <a class="dropdown-item" href="category.php?category=Travel">Travel</a>
                            <a class="dropdown-item" href="category.php?category=Food">Food</a>
                            <a class="dropdown-item" href="category.php?category=Health">Health</a>
                            <a class="dropdown-item" href="category.php?category=News">News</a>
                            <a class="dropdown-item" href="category.php?category=Finance & Business">Finance & Business</a>
                            <a class="dropdown-item" href="category.php?category=Tech">Tech</a>
                            <a class="dropdown-item" href="category.php?category=Gist">Gist</a>
                        </div>
                    </li>
                    <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#" style="font-family: Alatsi, sans-serif;">Sign In </a>
                        <div class="dropdown-menu"><a class="dropdown-item" href="admin/login.php">Login</a><a class="dropdown-item" href="admin/register.php">Register</a></div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- <nav class="navbar navbar-light navbar-expand-md d-print-none d-sm-none d-md-none d-lg-none d-xl-none d-xxl-none navigation-clean">
        <div class="container"><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-2"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-2"><a href="#" style="font-family: Alatsi, sans-serif;">First Item</a><a href="#" style="font-family: Alatsi, sans-serif;">Second Item</a><a href="#" style="font-family: Alatsi, sans-serif;">Third Item</a>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"></li>
                    <li class="nav-item" style="font-family: Alatsi, sans-serif;"></li>
                    <li class="nav-item" style="font-family: Alatsi, sans-serif;"></li>
                </ul>
            </div>
        </div>
    </nav> -->
   
    <div class="container">
        <div class="row ">
            <?php
                    if (isset($_GET['category'])) {
                        $category = $_GET['category'];
                        $sql = "SELECT * FROM post where category = '$category' ";
                        $query = mysqli_query($conn, $sql);
                        if ($query) {
                            while ($row = mysqli_fetch_assoc($query)) {
                                // $post_date = date('F j, Y', $row['post_date']);
                                $category = $row['category'];
                                $postid = $row['postid'];
                                $thumbnail = $row['thumbnail'];
                                $postid = $row['postid'];
                                $postid = $row['postid'];
                                        
                        
                ?>
            <h1 style="font-family: Alatsi, sans-serif;font-size: 56px ;padding-top: 40px;"><?php echo $category ?></h1>
            <small style="padding-bottom: 20px; color: #757575">Home       >     <?php echo $category ?></small><br><hr>


             <div class="container">
                <div class="row">
                    <div class="col-md-4" style="margin-top: 70px;">
                        <div class="card"><img class="card-img-top w-100 d-block" src="<?php echo $row['thumbnail'] ?>" height="200px">
                            <div class="card-body" style="padding-bottom: 30px;box-shadow: 0px 0px 6px var(--bs-gray-500);">
                                <a href="post.php?postid=<?php echo $row['postid']?>" style="text-decoration: none; color: black">
                                    <h4 class="card-title" style="padding-top: 20px;padding-left: 20px;font-family: Alatsi, sans-serif;font-weight: bold;"><?php echo truncate($row['title'], 50) ?></h4>
                                </a>
                                <p class="card-text" style="padding-left: 20px;padding-right: 20px;font-size: 13px;padding-bottom: 0px;color: var(--bs-gray-700);"><?php echo truncate($row['description'], 150) ?></p>
                                <small style="background: var(--bs-blue);color: var(--bs-white);font-family: Alatsi, sans-serif;padding: 5px;margin-left: 20px;margin-bottom: 30px;margin-top: -3px;"><?php echo $row['category'] ?></small>
                            </div>
                        </div>
                    </div>
                
                </div>
            </div>

            <?php }} else{?>
                <h1 style="font-family: Alatsi, sans-serif;font-size: 56px ;padding-top: 40px;text-align: center">No posts under this category</h1>
                <small style="padding-bottom: 20px; color: #757575">Home       >     <?php echo $category ?></small><br><hr>
            <?php }} ?>    
        </div>
    </div>
   
    
        <div class="container">
            <div class="row p-4">
                <div class="col-md-4">
                        <p class="Header" style="font-family: Alatsi, sans-serif;">News</p>
                        <hr>
                        <?php 
                            $query = "SELECT * FROM post WHERE category = 'News' LIMIT 3";
                            $result = mysqli_query($conn, $query);

                            while($row = mysqli_fetch_array($result))
                            {  
                                $id = urlencode($row['id']);
                        ?>
                        <div class="row pb-4">
                            <div class="col-4"><a href="post.php?postid=<?php echo $row['postid'] ?>"><img class="img-fluid"  src="<?php echo $row['thumbnail'] ?>" style="height: 100px;width: 100%; border-radius: 10px;"></a></div>
                            <div class="col-8 " style="border-radius: 10px;">
                                <a href="post.php?postid=<?php echo $row['postid'] ?>">
                                    <h3 class="name mt-4" style="font-family: Alatsi, sans-serif;font-size: 15px;"><?php echo truncate($row['title'], 90) ?></h3>
                                </a>
                            </div>
                        </div>
                        <?php } ?>
                    
                  
                </div>
                <div class="col-md-4">
                    <p class="Header" style="font-family: Alatsi, sans-serif;">Lifestyle</p>
                    <hr>
                  
                    <?php 
                            $query = "SELECT * FROM post WHERE category = 'Lifestyle' LIMIT 3";
                            $result = mysqli_query($conn, $query);

                            while($row = mysqli_fetch_array($result))
                            {  
                                $id = urlencode($row['id']);
                        ?>
                        <div class="row pb-4">
                            <div class="col-4"><a href="post.php?postid=<?php echo $row['postid'] ?>"><img class="img-fluid"  src="<?php echo $row['thumbnail'] ?>" style="height: 100px;width: 100%; border-radius: 10px;"></a></div>
                            <div class="col-8 " style="border-radius: 10px;">
                                <a href="post.php?postid=<?php echo $row['postid'] ?>">
                                    <h3 class="name mt-4" style="font-family: Alatsi, sans-serif;font-size: 15px;"><?php echo truncate($row['title'], 90) ?></h3>
                                </a>
                            </div>
                        </div>
                        <?php } ?>
                </div>
                <div class="col-md-4">
                    <p class="Header" style="font-family: Alatsi, sans-serif;">Gist</p>
                    <hr>
                  
                    <?php 
                            $query = "SELECT * FROM post WHERE category = 'Gist ' LIMIT 3";
                            $result = mysqli_query($conn, $query);

                            while($row = mysqli_fetch_array($result))
                            {  
                                $id = urlencode($row['id']);
                        ?>
                        <div class="row pb-4">
                            <div class="col-4"><a href="post.php?postid=<?php echo $row['postid'] ?>"><img class="img-fluid"  src="<?php echo $row['thumbnail'] ?>" style="height: 100px;width: 100%; border-radius: 10px;"></a></div>
                            <div class="col-8 " style="border-radius: 10px;">
                                <a href="post.php?postid=<?php echo $row['postid'] ?>">
                                    <h3 class="name mt-4" style="font-family: Alatsi, sans-serif;font-size: 15px;"><?php echo truncate($row['title'], 90) ?></h3>
                                </a>
                            </div>
                        </div>
                        <?php } ?>
                </div>
          </div>
        </div>
        <footer class="footer-dark" style="margin-top: 60px;">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>Company Name</h3>
                        <p>Praesent sed lobortis mi. Suspendisse vel placerat ligula. Vivamus ac sem lacus. Ut vehicula rhoncus elementum. Etiam quis tristique lectus. Aliquam in arcu eget velit pulvinar dictum vel in justo.</p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">Company Name © 2022</p>
            </div>
        </footer>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
</body>

</html>