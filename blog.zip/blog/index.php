<?php 

include 'admin/includes/config.php';
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);

function truncate($text, $chars = 25) {
    if (strlen($text) <= $chars) {
        return $text;
    }
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alatsi&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Highlight-Phone.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container">
            <a class="navbar-brand" href="index.php" style="color: var(--bs-blue);font-size: 30px;">
                <img src="thumbnail/logo.jpeg" alt="" width="50"  height="50">
            </a>
            <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1">
                <span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="index.php" style="font-family: Alatsi, sans-serif;">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php" style="font-family: Alatsi, sans-serif;">Admin</a></li>
                    <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#" style="font-family: Alatsi, sans-serif;">Categories </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="category.php?category=Lifestyles">Lifestyle</a>
                            <a class="dropdown-item" href="category.php?category=Education">Education</a>
                            <a class="dropdown-item" href="category.php?category=Travel">Travel</a>
                            <a class="dropdown-item" href="category.php?category=Food">Food</a>
                            <a class="dropdown-item" href="category.php?category=Health">Health</a>
                            <a class="dropdown-item" href="category.php?category=News">News</a>
                            <a class="dropdown-item" href="category.php?category=Finance & Business">Finance & Business</a>
                            <a class="dropdown-item" href="category.php?category=Tech">Tech</a>
                            <a class="dropdown-item" href="category.php?category=Gist">Gist</a>
                        </div>
                    </li>
                    <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#" style="font-family: Alatsi, sans-serif;">Sign In </a>
                        <div class="dropdown-menu"><a class="dropdown-item" href="admin/login.php">Login</a><a class="dropdown-item" href="admin/register.php">Register</a></div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="highlight-phone" style="background: url(&quot;assets/img/Exyo6XmU4AEYzV3.jpg&quot;) center / cover no-repeat, #ffffff;opacity: 1;filter: blur(0px);min-height: 500px;">
        <div class="container">
            <div class="row" style="margin-top: 20px;">
                <div class="col-lg-7 col-md-8 col-sm-12 mb-5" style="text-align: left;margin-top: 80px;height: auto;">
                    <p style="border-color: var(--bs-white);color: var(--bs-blue);font-weight: bold;font-size: 12px;margin-top: -30px;font-family: Alatsi, sans-serif;padding: 20px;padding-left: 20px;padding-right: 20px;padding-top: 0px;padding-bottom: 0px;">. TRAVEL</p>
                    <h2 class="pulse animated" style="border: 26px none var(--bs-white);font-size: 43.128px;width: 533px;font-family: Alatsi, sans-serif;padding: 20px;padding-top: 0px;padding-bottom: 0px;min-width: 524px;">How to Visit Bali's Monkey Forest</h2>
                    <p class="bounce animated" style="border-color: var(--bs-white);color: var(--bs-white);font-weight: bold;font-size: 15px;margin-top: -20px;padding-right: 20px;padding-left: 20px;">26th August 2020 .</p><a class="btn btn-primary" role="button" href="#" style="margin-left: 20px;">Read More</a>
                </div>
                <div class="col-lg-5 col-md-12 col-sm-12 pl-5 mt-5">
                    <?php 
                        $query = "SELECT * FROM post LIMIT 1";
                        $result = mysqli_query($conn, $query);

                        while($row = mysqli_fetch_array($result))
                        {  
                            $id = urlencode($row['id']);
                    ?>
                        <div class="container row mt-4 mb-4 ">
                            <div class="col-3">
                                <img class="img-fluid" src="<?php echo $row['thumbnail'] ?>" style="border-radius: 10px; width: 100% ;border-width: 2px;border-style: solid;">
                            </div>
                            <div class="col-9 mt-3">
                                <h3 class="pulse animated name" style="border-radius: 10px;margin-bottom: 0px;font-size: 20px;font-family: Alatsi, sans-serif;text-align: left;"><?php echo $row['title'] ?></h3>
                            </div>
                        </div>

                    <?php } ?>            

                </div>
               
            </div>
        </div>
    </section>
    <div class="container">
        <div class="row ">
            <div class="col-md-8 col-sm-12" style="height: 500px;">
                <?php 
                    $query = "SELECT * FROM post LIMIT 1";
                    $result = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result))
                    {  
                        $id = urlencode($row['id']);
                ?>
                    <div class="card">
                        <div class="card-img-overlay d-table float-start flex-row-reverse" data-aos="fade" data-aos-duration="200" style="background: url(&quot;<?php echo $row['thumbnail'] ?>&quot;) no-repeat, #ffffff;margin-top: 100px; background-size: cover; background-position: center ;min-height: 450px;border-radius: 10px;box-shadow: 0px 0px 5px 1px var(--bs-gray-400);height: 356px;width: 100%; background-size: cover, auto;padding-top: 0px;">
                            <a href="post.php?postid=<?php echo $row['postid']?>" style="background-color: #0000;text-shadow: 2px 2px blue ;text-decoration: none; color: black">
                                <h4 class="bounce animated" style="margin-top: 270px;padding-left: 20px;color: var(--bs-white);font-size: 29px;font-family: Alatsi, sans-serif;box-shadow: 0px 0px 0px var(--bs-gray);"><?php echo $row['title'] ?></h4>
                            </a>    
                            <p style="text-shadow: 2px 2px blue;margin-left: 20px;color: var(--bs-white);font-size: 12px;font-weight: bold;margin-top: 10px;"><?php echo $row['date'] ?></p>
                        </div>
                    </div>
                <?php } ?>
                <h1 style="font-family: Alatsi, sans-serif;font-size: 16.88000000000001px;padding-top: 40px;">Latest Updates</h1><hr>
                <!-- <h1 style="padding: 100px;font-size: 16.88000000000001px;color: var(--bs-dark);padding-top: 40px;padding-left: 10%;padding-bottom: 0px;font-family: Alatsi, sans-serif;width: 100%;margin-top: 30px;">Latest Posts</h1> -->
            </div>

            <?php 
                    $query = "SELECT * FROM post LIMIT 1 OFFSET 2";
                    $result = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result))
                    {  
                        $id = urlencode($row['id']);
            ?>
                <div class="col-md-4" style="margin-top: 100px;">
                    <div class="card">
                        <img class="card-img-top w-100 d-block" src="<?php echo $row['thumbnail'] ?>" height="290px">
                        <div class="card-body" style="padding-bottom: 30px;box-shadow: 0px 0px 6px var(--bs-gray-500);">
                            <a href="post.php?postid=<?php echo $row['postid']?>" style="text-decoration: none; color: black">
                                <h4 class="card-title" style="padding-top: 20px;padding-left: 20px;font-family: Alatsi, sans-serif;font-weight: bold;"><?php echo truncate($row['title'], 50) ?></h4>
                            </a>
                            <p class="card-text" style="padding-left: 20px;padding-right: 20px;font-size: 13px;padding-bottom: 0px;color: var(--bs-gray-700);"><?php echo truncate($row['description'], 150) ?></p>
                            <small style="background: var(--bs-blue);color: var(--bs-white);font-family: Alatsi, sans-serif;padding: 5px;margin-left: 20px;margin-bottom: 30px;margin-top: -3px;"><?php echo $row['category'] ?></small>
                        </div>
                    </div>
                </div>

            <?php } ?>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php 
                $query = "SELECT * FROM post DESC LIMIT 100 OFFSET 2 ";
                $result = mysqli_query($conn, $query);

                while($row = mysqli_fetch_array($result))
                {  
                    $id = urlencode($row['id']);
            ?>
                <div class="col-md-4" style="margin-top: 70px;">
                    <div class="card"><img class="card-img-top w-100 d-block" src="<?php echo $row['thumbnail'] ?>" height="200px">
                        <div class="card-body" style="height: 250px; padding-bottom: 30px;box-shadow: 0px 0px 6px var(--bs-gray-500);">
                            <a href="post.php?postid=<?php echo $row['postid']?>" style="text-decoration: none; color: black">
                                <h4 class="card-title" style="padding-top: 20px;padding-left: 20px;font-family: Alatsi, sans-serif;font-weight: bold;"><?php echo truncate($row['title'], 50) ?></h4>
                            </a>
                            <p class="card-text" style="padding-left: 20px;padding-right: 20px;font-size: 13px;padding-bottom: 0px;color: var(--bs-gray-700);"><?php echo truncate($row['description'], 100) ?></p>
                            <small style="background: var(--bs-blue);color: var(--bs-white);font-family: Alatsi, sans-serif;padding: 5px;margin-left: 20px;margin-bottom: 30px;margin-top: -3px;"><?php echo $row['category'] ?></small>
                        </div>
                    </div>
                </div>

            <?php }  ?>
           
        </div>
    </div>
    <section class="projects-horizontal">
        <div class="container">
        <h1 style=";font-size: 16.88000000000001px;color: var(--bs-dark);padding-top: 40px;padding-bottom: 0px;font-family: Alatsi, sans-serif;width: 100%;margin-top: 30px;">Latest Posts</h1>

            <div class="intro"></div>
            <div class="row projects">
                <?php 
                            $query = "SELECT * FROM post LIMIT 4";
                            $result = mysqli_query($conn, $query);

                            while($row = mysqli_fetch_array($result))
                            {  
                                $id = urlencode($row['id']);
                        ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 item" style="padding-top: 30px;">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-6">
                                <a href="#">
                                    <img class="img-fluid" src="<?php echo $row['thumbnail'] ?>" style="border-radius: 10px; height: 150px; width: 100%"></a>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-6 mt-3">
                                <a href="post.php?postid=<?php echo $row['postid']?>" style="text-decoration: none; color: black">
                                    <h3 class="name p-3" style="font-family: Alatsi, sans-serif;font-size: 21px;"><?php echo truncate($row['title'], 60) ?>...</h3>
                                </a>
                                <!-- <p class="description p-3" style="font-family: Alatsi, sans-serif;color: var(--bs-indigo);"><?php echo $row['category'] ?></p> -->

                            </div>
                        </div>
                    </div>
                <?php } ?>
                
            </div>
        </div>
    </section>
    
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                        <p class="Header" style="font-family: Alatsi, sans-serif;">News</p>
                        <hr>
                        <?php 
                            $query = "SELECT * FROM post WHERE category = 'News' LIMIT 3";
                            $result = mysqli_query($conn, $query);

                            while($row = mysqli_fetch_array($result))
                            {  
                                $id = urlencode($row['id']);
                        ?>
                        <div class="row pb-4">
                            <div class="col-4"><a href="post.php?postid=<?php echo $row['postid'] ?>"><img class="img-fluid"  src="<?php echo $row['thumbnail'] ?>" style="height: 100px;width: 100%; border-radius: 10px;"></a></div>
                            <div class="col-8 " style="border-radius: 10px;">
                                <a href="post.php?postid=<?php echo $row['postid'] ?>">
                                    <h3 class="name mt-4" style="font-family: Alatsi, sans-serif;font-size: 15px;"><?php echo truncate($row['title'], 90) ?></h3>
                                </a>
                            </div>
                        </div>
                        <?php } ?>
                        
                    
                  
                </div>
                <div class="col-md-4">
                    <p class="Header" style="font-family: Alatsi, sans-serif;">Politics</p>
                    <hr>
                  
                    <?php 
                        $query = "SELECT * FROM post WHERE category = 'Politics' LIMIT 3";
                        $result = mysqli_query($conn, $query);

                        while($row = mysqli_fetch_array($result))
                        {  
                            $id = urlencode($row['id']);
                    ?>
                        <div class="row pb-4">
                            <div class="col-4"><a href="#"><img class="img-fluid"  src="<?php echo $row['thumbnail'] ?>" style="height: 100px;width: 100%;border-radius: 10px;"></a></div>
                            <div class="col-8 " style="border-radius: 10px;">
                                <a href="post.php?postid=<?php echo $row['postid']?>" style="text-decoration: none; color: black">
                                    <h3 class="name p-3" style="font-family: Alatsi, sans-serif;font-size: 21px;"><?php echo truncate($row['title'], 60) ?>...</h3>
                                </a>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-12">
                    <p class="Header" style="font-family: Alatsi, sans-serif;">Gists</p>
                    <hr>
                        <?php 
                            $query = "SELECT * FROM post WHERE category = 'Gist' LIMIT 3";
                            $result = mysqli_query($conn, $query);

                            while($row = mysqli_fetch_array($result))
                            {  
                                $id = urlencode($row['id']);
                        ?>
                            <div class="row pb-4">
                                <div class="col-4"><a href="#"><img class="img-fluid"  src="<?php echo $row['thumbnail'] ?>" style="height: 100px;width: 100%; border-radius: 10px;"></a></div>
                                <div class="col-8 " style="border-radius: 10px;float: left; padding-left: 0px;">
                                    <a href="post.php?postid=<?php echo $row['postid']?>" style="text-decoration: none; color: black;">
                                        <h3 class="name p-3" style="font-family: Alatsi, sans-serif;font-size: 15px;"><?php echo truncate($row['title'], 60) ?>...</h3>
                                    </a>
                                </div>
                            </div>
                        <?php } ?>
                   
                </div>
            </div>
        </div>
        <footer class="footer-dark" style="margin-top: 60px;">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>Company Name</h3>
                        <p>Praesent sed lobortis mi. Suspendisse vel placerat ligula. Vivamus ac sem lacus. Ut vehicula rhoncus elementum. Etiam quis tristique lectus. Aliquam in arcu eget velit pulvinar dictum vel in justo.</p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">Company Name © 2022</p>
            </div>
        </footer>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
</body>

</html>